"""Runs pooling_block through ModelSim/Questa on a 256x256 test image.

pooling_block addresses its input/output memories with an 18-bit bus, so a
256x256x3 image (196608 elements) fits in a single run with all channels
pooled in parallel.

Requires pooling_tb.vhd (in this directory) and vcom/vsim (ModelSim or Questa)
on PATH.
"""
import tb_common as tbc

PNG_INPUT = "input.png"
OUTPUT_PNG = "output_pool.png"
DESIGN_FILES = ["FPGA_accelerator.vhd", "pooling_block.vhd"]
TB_FILE = "pooling_tb.vhd"
TB_ENTITY = "pooling_tb"

CHANNELS = 3
POOL_SIZE = 2
STRIDE = 2
POOL_TYPE = "MAX_POOL"  # MAX_POOL | AVERAGE_POOL | MIN_POOL | SUM_POOL


def main():
    img = tbc.load_image(PNG_INPUT)
    width, height = img.size
    print(f"Loaded PNG: {width}x{height}")
    assert width * height * CHANNELS <= 262144, "Image too large for pooling_block's 18-bit address bus"

    values = tbc.image_to_interleaved(img)
    tbc.write_values("input.txt", values)

    out_h = (height - POOL_SIZE) // STRIDE + 1
    out_w = (width - POOL_SIZE) // STRIDE + 1

    generics = {
        "INPUT_HEIGHT": height,
        "INPUT_WIDTH": width,
        "CHANNELS": CHANNELS,
        "POOL_SIZE": POOL_SIZE,
        "STRIDE": STRIDE,
        "POOL_TYPE_STR": POOL_TYPE,
        "OUTPUT_HEIGHT": out_h,
        "OUTPUT_WIDTH": out_w,
    }

    print("Running pooling testbench...")
    tbc.compile_and_run(DESIGN_FILES, TB_FILE, TB_ENTITY, generics)

    out_values = tbc.read_values("output.txt", out_h * out_w * CHANNELS)
    out_img = tbc.interleaved_to_image(out_values, out_w, out_h, CHANNELS)
    out_img.save(OUTPUT_PNG)
    print(f"Saved output image to {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
