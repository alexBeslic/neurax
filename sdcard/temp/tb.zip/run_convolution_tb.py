"""Runs convolution_block through ModelSim/Questa on a 256x256 test image.

convolution_block addresses its input/weight memories with a 16-bit bus, so at
most 65536 elements (INPUT_HEIGHT*INPUT_WIDTH*INPUT_CHANNELS) can be
addressed. For a 256x256 image (65536 pixels) this means only one color
channel ("plane") can be processed per simulation run, so this script runs
convolution_tb once per R/G/B plane and recombines the filtered planes into
the output image.

Requires convolution_tb.vhd (in this directory) and vcom/vsim (ModelSim or
Questa) on PATH.
"""
import tb_common as tbc

PNG_INPUT = "input.png"
OUTPUT_PNG = "output_conv.png"
DESIGN_FILES = ["FPGA_accelerator.vhd", "convolution_block.vhd"]
TB_FILE = "convolution_tb.vhd"
TB_ENTITY = "convolution_tb"

KERNEL_SIZE = 3
STRIDE = 1
PADDING = 1

# 3x3 box-blur kernel in Q8.8 fixed point (weight_raw = round(weight * 256));
# taps sum to ~256 (1.0) so the filtered output stays in the 0-255 pixel range.
BOX_BLUR_Q88 = [28, 28, 28,
                28, 29, 28,
                28, 28, 28]
BIAS_Q88 = [0]


def run_channel(width, height, plane, channel_name):
    tbc.write_values("input.txt", plane)
    tbc.write_values("weight.txt", BOX_BLUR_Q88)
    tbc.write_values("bias.txt", BIAS_Q88)

    out_h = (height + 2 * PADDING - KERNEL_SIZE) // STRIDE + 1
    out_w = (width + 2 * PADDING - KERNEL_SIZE) // STRIDE + 1

    generics = {
        "INPUT_HEIGHT": height,
        "INPUT_WIDTH": width,
        "INPUT_CHANNELS": 1,
        "OUTPUT_CHANNELS": 1,
        "KERNEL_SIZE": KERNEL_SIZE,
        "STRIDE": STRIDE,
        "PADDING": PADDING,
        "OUTPUT_HEIGHT": out_h,
        "OUTPUT_WIDTH": out_w,
    }

    print(f"Running convolution testbench for {channel_name} channel...")
    tbc.compile_and_run(DESIGN_FILES, TB_FILE, TB_ENTITY, generics)

    return tbc.read_values("output.txt", out_h * out_w), out_w, out_h


def main():
    img = tbc.load_image(PNG_INPUT)
    width, height = img.size
    print(f"Loaded PNG: {width}x{height}")
    assert width * height <= 65536, "Image too large for convolution_block's 16-bit address bus"

    r, g, b = tbc.image_to_planes(img)

    out_planes = {}
    out_w = out_h = None
    for idx, (name, plane) in enumerate([("R", r), ("G", g), ("B", b)]):
        values, out_w, out_h = run_channel(width, height, plane, name)
        out_planes[idx] = values

    out_img = tbc.planes_to_image(out_planes, out_w, out_h)
    out_img.save(OUTPUT_PNG)
    print(f"Saved output image to {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
