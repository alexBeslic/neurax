"""Runs activation_block through ModelSim/Questa on a 256x256 test image.

activation_block only accepts tensor_size <= MAX_TENSOR_SIZE (4096), so the
flattened image (256*256*3 = 196608 elements) is processed in chunks;
activation_tb loops over the chunks internally so this script only needs to
run vsim once.

Requires activation_tb.vhd (in this directory) and vcom/vsim (ModelSim or
Questa) on PATH.
"""
import tb_common as tbc

PNG_INPUT = "input.png"
OUTPUT_PNG = "output_act.png"
DESIGN_FILES = ["FPGA_accelerator.vhd", "activation_block.vhd"]
TB_FILE = "activation_tb.vhd"
TB_ENTITY = "activation_tb"

CHANNELS = 3
CHUNK_SIZE = 4096  # must divide TOTAL_ELEMENTS and be <= MAX_TENSOR_SIZE
ACT_TYPE = "RELU"  # RELU | SIGMOID | TANH | LINEAR | LEAKY_RELU | ELU
ALPHA_Q88 = 26     # ~0.1 in Q8.8, used by LEAKY_RELU / ELU


def main():
    img = tbc.load_image(PNG_INPUT)
    width, height = img.size
    print(f"Loaded PNG: {width}x{height}")

    total_elements = width * height * CHANNELS
    assert total_elements % CHUNK_SIZE == 0, "CHUNK_SIZE must evenly divide the flattened image size"

    values = tbc.image_to_interleaved(img)
    tbc.write_values("input.txt", values)

    generics = {
        "TOTAL_ELEMENTS": total_elements,
        "CHUNK_SIZE": CHUNK_SIZE,
        "ACT_TYPE_STR": ACT_TYPE,
        "ALPHA_RAW": ALPHA_Q88,
    }

    print("Running activation testbench...")
    tbc.compile_and_run(DESIGN_FILES, TB_FILE, TB_ENTITY, generics)

    out_values = tbc.read_values("output.txt", total_elements)
    out_img = tbc.interleaved_to_image(out_values, width, height, CHANNELS)
    out_img.save(OUTPUT_PNG)
    print(f"Saved output image to {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
